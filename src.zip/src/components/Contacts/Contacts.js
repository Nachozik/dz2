import React from "react";

const Contacts = () => {
        return <div>
            +996706440330
            email:eyeless.sad.u@gmail.com
        </div>
};

export default Contacts;