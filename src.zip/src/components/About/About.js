import React from "react";

const About = () => {
    return <div>
        Добро пожаловать в наш реактив!
    </div>
};

export default About;