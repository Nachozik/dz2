import './App.css';
import React from "react";
import {Link, BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Contacts from "./components/Contacts/Contacts";
import About from "./components/About/About";

function App() {
  return (
    <div className="App">
        <nav>
          <Link to="/">Домой</Link>
          <Link to="/about">О нас</Link>
          <Link to="/contacts">Контактс</Link>
        </nav>
        <Routes>
            <Route path="/about" element={<About/>}/>
            <Route path="/about" element={<Contacts/>}/>
        </Routes>
    </div>
  );
}

export default App;
